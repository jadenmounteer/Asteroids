"""
File: ship.py
Author: Jaden Mounteer

This file creates a ship class, a child of the
flying object class.
"""
# Imports
import arcade
from flying_object import Flying_object
import asteroids_game
import math


class Ship(Flying_object):
    """
    Represents a starship controlled
    by the player. It is a child class
    of the Flying_object base class.
    """
    def __init__(self):
        """ Initiates the ship's member variables."""
        # Calls the super function so that we can manipulate
        # some of the flying object's methods, while keeping others.
        super().__init__()

        # Sets the ship's starting position to be the middle of the screen.
        self.center.x = asteroids_game.SCREEN_HEIGHT / 2
        self.center.y = asteroids_game.SCREEN_WIDTH / 2

        # Sets the ship's velocity
        self.velocity.dx = 0
        self.velocity.dy = 0

        # Creates an attribute for the starting angle of the ship.
        self._angle = 90

        # Creates an attribute for the starting angle of the ship in radians.
        self.angle_rad = 0

    def draw(self):
        """
        Draws the ship to the screen.
        :return: None
        """
        # Sets the texture of the ship to be the image playerShip1_orange.png
        # found in the Image directory.
        img = "Images/playerShip1_orange.png"

        # loads the image into a texture class with the image as a parameter.
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255  # For transparency, 255 means not transparent.

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, (self._angle - 90), alpha)

    def thrust(self):
        """
        Increases the velocity of the ship in the direction
        it is pointed by 0.25 pixels/frame
        """
        # Convert angle in degrees to radians.
        self.angle_rad = math.radians(self._angle)

        # Increases the velocity of the ship based on the angle.
        self.velocity.dx += math.cos(self.angle_rad) * asteroids_game.SHIP_THRUST_AMOUNT
        self.velocity.dy += math.sin(self.angle_rad) * asteroids_game.SHIP_THRUST_AMOUNT












