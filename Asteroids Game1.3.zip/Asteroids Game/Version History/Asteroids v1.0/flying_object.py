"""
File: flying_object.py
Author: Jaden Mounteer

This file creates a parent class to represent a flying
object in the game.
"""
# ___IMPORTS___
# Imports the Point class
from point import Point
# Imports the Velocity class
from velocity import  Velocity
# Imports ABC in order to work with
# abstract methods.
from abc import ABC
from abc import abstractmethod

class Flying_object(ABC):
    """
    A parent class to represent a flying
    object in the game.
    """
    def __init__(self):
        # Creates a center attribute from the Point class.
        # Represents the x and y coordinate of the object.
        self.center = Point()

        # Creates a velocity attribute from the Velocity class.
        # Represents the velocity of the object comprised of the
        # dx and dy attributes.
        self.velocity = Velocity()

        # Creates an alive attribute and sets it to true.
        # Makes the game know that the flying object is currently
        # alive.
        self.alive = True

    def advance(self):
        """
        Makes the flying object move.
        :return: None
        """
        pass

    # Creates an abstract draw() method as a visual reminder
    # that all flying_object child classes will have their own
    # version of this method.
    @abstractmethod
    def draw(self):
        """
        This method will draw the object,
        whatever it is.
        :return: None
        """
        pass

    def is_off_screen(self, screen_width, screen_height):
        """
        :param: screen_width
        :param: screen_height
        Checks to see if the object is on or off the screen.
        :return: Boolean
        """
        pass








