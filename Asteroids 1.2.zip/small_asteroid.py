"""
File: small_asteroid.py
Author: Jaden Mounteer

This file creates a parent class to represent a small asteroid
in the game.
"""

# Imports
import asteroid_base_class

class small_asteroid(asteroid_base_class.Asteroid):
    """
    Represents a small asteroid in the game.
    Child class of the asteroid class. Does
    not break apart into smaller peices like
    the other asteroids.
    """
    def __init__(self):
        # Calls the super function so that we can manipulate
        # some of the asteroid's methods, while keeping others.
        super().__init__()

        # Initiates the location of the asteroid.
        self.center.x = 100
        self.center.y = 100

        # Initiates the speed of the asteroid.
        self.velocity.dx = 50
        self.velocity.dy = 50

    def draw(self):
        """
        Draws the asteroid to the screen.
        """
        pass

    def hit(self):
        """
        Simulates the asteroid being hit.
        :return: a point for the player.
        """
        pass