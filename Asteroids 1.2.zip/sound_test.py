import arcade

arcade.open_window(300, 300, "Sound Demo")
laser_sound = arcade.load_sound("dodgeball_mixdown.m4a")
arcade.play_sound(laser_sound)
arcade.run()