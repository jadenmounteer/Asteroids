"""
File: medium_asteroid.py
Author: Jaden Mounteer

This file creates a parent class to represent a medium asteroid
in the game.
"""

# Imports
import asteroid_base_class

class medium_asteroid(asteroid_base_class.Asteroid):
    """
    Represents a medium asteroid in the game.
    Child class of the asteroid class.
    """
    def __init__(self):
        # Calls the super function so that we can manipulate
        # some of the asteroid's methods, while keeping others.
        super().__init__()

        # Initiates the location of the asteroid.
        self.center.x = 100
        self.center.y = 100

        # Initiates the speed of the asteroid.
        self.velocity.dx = 50
        self.velocity.dy = 50

    def draw(self):
        """
        Draws the asteroid to the screen.
        """
        pass

    def break_apart(self):
        """
        Causes the asteroid to break apart and split into
        small asteroids.
        """
        pass

    def hit(self):
        """
        Simulates the asteroid being hit.
        :return: a point for the player.
        """
        pass
