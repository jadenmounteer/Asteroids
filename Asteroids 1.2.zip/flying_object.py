"""
File: flying_object.py
Author: Jaden Mounteer

This file creates a parent class to represent a flying
object in the game.
"""
# ___IMPORTS___
# Imports the Point class
from point import Point
# Imports the Velocity class
from velocity import  Velocity
# Imports ABC in order to work with
# abstract methods.
from abc import ABC
from abc import abstractmethod
import arcade

class Flying_object(arcade.Sprite):
    """
    A parent class to represent a flying
    object in the game. Child class of the
    arcade.sprite class.
    """
    def __init__(self):
        super().__init__()
        # Creates a center attribute from the Point class.
        # Represents the x and y coordinate of the object.
        self.center = Point()

        # Creates a velocity attribute from the Velocity class.
        # Represents the velocity of the object comprised of the
        # dx and dy attributes.
        self.velocity = Velocity()

        # Creates an alive attribute and sets it to true.
        # Makes the game know that the flying object is currently
        # alive.
        self.alive = True

    def advance(self):
        """
        Makes the flying object move.
        :return: None
        """
        if self.alive:
            self.center.x += self.velocity.dx
            self.center.y += self.velocity.dy

    # Creates an abstract draw() method as a visual reminder
    # that all flying_object child classes will have their own
    # version of this method.
    @abstractmethod
    def draw(self):
        """
        This method will draw the object,
        whatever it is.
        :return: None
        """
        pass








