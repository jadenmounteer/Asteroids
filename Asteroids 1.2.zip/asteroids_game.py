"""
File: asteroids.py
Original Author: Br. Burton
Completed By: Jaden Mounteer

This program implements the asteroids game. It uses all of
classes to create the game class. It also defines the global constants
of the game.
"""
# ___IMPORTS___
import arcade
from abc import ABC
from abc import abstractmethod
from ship import Ship
from large_asteroid import Large_asteroid
from bullet import Bullet
import math

# These are Global constants to use throughout the game
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

BULLET_RADIUS = 30
BULLET_SPEED = 10
BULLET_LIFE = 60

SHIP_TURN_AMOUNT = 3
SHIP_THRUST_AMOUNT = 0.25
SHIP_RADIUS = 30

INITIAL_ROCK_COUNT = 5

BIG_ROCK_SPIN = 1
BIG_ROCK_SPEED = 1.5
BIG_ROCK_RADIUS = 15

MEDIUM_ROCK_SPIN = -2
MEDIUM_ROCK_RADIUS = 5

SMALL_ROCK_SPIN = 5
SMALL_ROCK_RADIUS = 2




class Game(arcade.Window):
    """
    This class handles all the game callbacks and interaction
    This class will then call the appropriate functions of
    each of the above classes.
    You are welcome to modify anything in this class.
    """

    def __init__(self, width, height, title):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        """
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.SMOKY_BLACK) #SMOKY_BLACK

        self.held_keys = set()

        # TODO: declare anything here you need the game class to track
        # Creates an object to represent the ship as an instance of the
        # Ship class.
        self.ship = Ship()

        # Creates the 5 large asteroid objects to begin the game.
        self.large_asteroid1 = Large_asteroid(100, 100)
        self.large_asteroid2 = Large_asteroid(200, 500)
        self.large_asteroid3 = Large_asteroid(650, 400)
        self.large_asteroid4 = Large_asteroid(600, 200)
        self.large_asteroid5 = Large_asteroid(700, 250)

        # Creates a list for the asteroids.
        self.asteroids = [self.large_asteroid1, self.large_asteroid2, self.large_asteroid3, self.large_asteroid4,
                     self.large_asteroid5]

        # Creates a list to hold the bullets in
        self.bullets = []

        # Loads the sound file for the bullets
        self.laser_sound = arcade.load_sound("laser.ogg")

        # Loads the sound file for the background music
        self.music = arcade.load_sound("dodgeball_mixdown copy.ogg")

    def play_music(self):
        arcade.play_sound(self.music)

    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()

        # TODO: draw each object
        # Iterates through the bullets and draws them
        for bullet in self.bullets:
            bullet.draw()

        # Draws the ship to the screen.
        self.ship.draw()

        # Draws the asteroids to the screen.
        for asteroid in self.asteroids:
            asteroid.draw()



    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """


        # Checks to see if there are any keys being pressed.
        self.check_keys()

        # Cleans up any zombies from the game.
        self.cleanup_zombies()

        # TODO: Tell everything to advance or move forward one step in time.
        # Advances the asteroids.
        for asteroid in self.asteroids:
            asteroid.advance()

        # Advances the ship
        self.ship.advance()

        # Iterates through the list of bullets and tells each one to advance.
        for bullet in self.bullets:
            bullet.advance()

        # Checks for collisions.
        self.check_collisions()

    def check_keys(self):
        """
        This function checks for keys that are being held down.
        You will need to put your own method calls in here.
        """
        if arcade.key.LEFT in self.held_keys:
            self.ship._angle += SHIP_TURN_AMOUNT

        if arcade.key.RIGHT in self.held_keys:
            self.ship._angle -= SHIP_TURN_AMOUNT

        if arcade.key.UP in self.held_keys:
            # Increases the velocity of the ship in the direction it is pointed.
            self.ship.thrust()

        #___TESTING___
        if arcade.key.T in self.held_keys:
            #print("Ship x coordinate: " + str(self.ship.center.x))
            #print("Ship y coordinate: " + str(self.ship.center.y))
            print("Dx: " + str(self.ship.velocity.dx))
            print("Dy: " + str(self.ship.velocity.dy))


        # Machine gun mode...
        #if arcade.key.SPACE in self.held_keys:
        #    pass


    def on_key_press(self, key: int, modifiers: int):
        """
        Puts the current key in the set of keys that are being held.
        You will need to add things here to handle firing the bullet.
        """
        if self.ship.alive:
            self.held_keys.add(key)
            # Fires the bullet.
            if key == arcade.key.SPACE:
                # Plays the sound effect
                arcade.play_sound(self.laser_sound)
                # Creates an instance of a bullet
                bullet = Bullet(self.ship.center.x, self.ship.center.y, self.ship._angle,
                                self.ship.velocity.dx, self.ship.velocity.dy)
                # Calls the bullet's fire method.
                #bullet.fire(angle_degrees)
                # Appends the bullet to the list of bullets.
                self.bullets.append(bullet)

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            self.held_keys.remove(key)

        # Stops the ship from rotating if the left or right keys are released.
        if key == arcade.key.LEFT or key == arcade.key.RIGHT:
            self.ship.change_angle = 0

    def _get_angle_degrees(self, x, y):
        """
        Gets the value of an angle (in degrees) defined
        by the provided x and y.
        Note: This could be a static method, but we haven't
        discussed them yet...
        """
        # get the angle in radians
        angle_radians = math.atan2(y, x)

        # convert to degrees
        angle_degrees = math.degrees(angle_radians)

        return angle_degrees

    def cleanup_zombies(self):
        """
        Removes any dead bullets and asteroids
        from their lists, hence, removes them
        from the game.
        :return:
        """
        # Cleans up the dead bullets.
        for bullet in self.bullets:
            if not bullet.alive:
                self.bullets.remove(bullet)

        # Cleans up the dead asteroids.
        for asteroid in self.asteroids:
            if not asteroid.alive:
                self.asteroids.remove(asteroid)

    def check_collisions(self):
        """
        Checks to see if bullets have hit asteroids.
        Checks to see if asteroids and the ship have collided.
        Removes dead items.
        :return: None
        """

        # Checks to see if bullets and asteroids have collided.
        for bullet in self.bullets:
            for asteroid in self.asteroids:
                # Make sure they are both alive before checking for a collision
                if bullet.alive and asteroid.alive:
                    too_close = bullet.radius + asteroid.radius

                    if (abs(bullet.center.x - asteroid.center.x) < too_close and
                            abs(bullet.center.y - asteroid.center.y) < too_close):
                        # its a hit! Changes the bullet and asteroid attributes to False.
                        bullet.alive = False
                        asteroid.alive = False

                        # We will wait to remove the dead objects until after we
                        # finish going through the list
        # TODO: Check for ship/asteroid collisions here.

        # Checks for anything that is dead, and removes it
        self.cleanup_zombies()

