"""
File: large_asteroid.py
Author: Jaden Mounteer

This file creates a parent class to represent a large asteroid
in the game.
"""

# Imports
import asteroid_base_class
import arcade
import random

class Large_asteroid(asteroid_base_class.Asteroid):
    """
    Represents a large asteroid in the game.
    Child class of the asteroid class.
    """
    def __init__(self, x, y):
        """
        Takes x and y coordinates as the starting location.
        """
        # Calls the super function so that we can manipulate
        # some of the asteroid's methods, while keeping others.
        super().__init__()

        # Initiates the location of the asteroid at the x and y parameters.
        self.center.x = x
        self.center.y = y

        # Initiates the speed of the asteroid. Moves at 1.5 pixels per frame
        # at a random initial direction.
        self.velocity.dx = random.uniform(-1.5, 1.5)
        self.velocity.dy = random.uniform(-1.5, 1.5)

        # Initiates a radius attribute for collision detection.
        self.radius = 15

    def draw(self):
        """
        Draws the asteroid to the screen.
        """
        img = "Images/meteorGrey_big1.png"
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255

        x = self.center.x
        y = self.center.y
        angle = 90

        arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha)


    def break_apart(self):
        """
        Causes the asteroid to break apart and split into two
        medium asteroids and one small one.
        """
        pass

    def hit(self):
        """
        Simulates the asteroid being hit.
        :return: a point for the player.
        """
        pass
