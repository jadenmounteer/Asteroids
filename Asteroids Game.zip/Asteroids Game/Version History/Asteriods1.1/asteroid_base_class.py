"""
File: asteroid_base_class.py
Author: Jaden Mounteer

This file creates a parent class to represent an asteroid
in the game.
"""
# ___IMPORTS___
# Imports ABC in order to work with
# abstract methods.
import arcade
from abc import ABC
from abc import abstractmethod
#from point import Point
from velocity import Velocity
from point import Point


class Asteroid(ABC):
    """
    An abstract base class for the
    asteroids in the game.
    """
    def __init__(self):
        # Initiates the location of the asteroid.
        self.center = Point()

        # Initiates the velocity of the asteroid.
        self.velocity = Velocity()

    def advance(self):
        """
        Moves the asteroid in accordance to its
        dx and dy velocity attributes.
        :return: None
        """
        self.center.x += self.velocity.dx
        self.center.y += self.velocity.dy

    @abstractmethod
    def draw(self):
        """
        Draws the asteroid to the screen.
        :return: None
        """
        pass

    @abstractmethod
    def hit(self):
        """
        Simulates the asteroid being hit by another object.
        :return: None
        """
        pass

    def rotate(self):
        """
        Simulates the asteroid rotating in space.
        :return: None
        """
        pass


