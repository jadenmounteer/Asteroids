"""
File: bullet.py
Author: Jaden Mounteer

This file creates a bullet class, a child of the
flying object class.
"""
# Imports
from flying_object import Flying_object
import asteroids_game


class Bullet(Flying_object):
    """
    Represents a bullet in the game, a child
    of the flying object class.
    """
    def __init__(self):
        # Calls the super function so that we can manipulate
        # some of the flying object's methods, while keeping others.
        super().__init__()

        # Sets the location of the bullet
        self.center.x = 50
        self.center.y = 50

        # Sets the velocity of the bullet
        self.velocity.dx = asteroids_game.BULLET_SPEED
        self.velocity.dy = asteroids_game.BULLET_SPEED

    def draw(self):
        """
        Draws the bullet to the screen.
        """
        pass

    def fire(self):
        """
        Fires the bullet.
        :return: None
        """
        pass