"""
File: asteroids.py
Original Author: Br. Burton
Completed By: Jaden Mounteer

This program implements the asteroids game. It uses all of
classes to create the game class. It also defines the global constants
of the game.
"""
# ___IMPORTS___
import arcade
from abc import ABC
from abc import abstractmethod
from ship import Ship
from large_asteroid import Large_asteroid

# These are Global constants to use throughout the game
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

BULLET_RADIUS = 30
BULLET_SPEED = 10
BULLET_LIFE = 60

SHIP_TURN_AMOUNT = 3
SHIP_THRUST_AMOUNT = 0.25
SHIP_RADIUS = 30

INITIAL_ROCK_COUNT = 5

BIG_ROCK_SPIN = 1
BIG_ROCK_SPEED = 1.5
BIG_ROCK_RADIUS = 15

MEDIUM_ROCK_SPIN = -2
MEDIUM_ROCK_RADIUS = 5

SMALL_ROCK_SPIN = 5
SMALL_ROCK_RADIUS = 2




class Game(arcade.Window):
    """
    This class handles all the game callbacks and interaction
    This class will then call the appropriate functions of
    each of the above classes.
    You are welcome to modify anything in this class.
    """

    def __init__(self, width, height):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        """
        super().__init__(width, height)
        arcade.set_background_color(arcade.color.SMOKY_BLACK) #SMOKY_BLACK

        self.held_keys = set()

        # TODO: declare anything here you need the game class to track
        # Creates an object to represent the ship as an instance of the
        # Ship class.
        self.ship = Ship()

        # Creates the 5 large asteroid objects to begin the game.
        self.large_asteroid1 = Large_asteroid()
        self.large_asteroid2 = Large_asteroid()
        self.large_asteroid3 = Large_asteroid()
        self.large_asteroid4 = Large_asteroid()
        self.large_asteroid5 = Large_asteroid()

    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()

        # TODO: draw each object
        # Draws the ship to the screen.
        self.ship.draw()

        # Draws the large asteroids to the screen.
        self.large_asteroid1.draw()
        self.large_asteroid2.draw()
        self.large_asteroid3.draw()
        self.large_asteroid4.draw()
        self.large_asteroid5.draw()

    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """
        self.check_keys()

        # TODO: Tell everything to advance or move forward one step in time
        # Advances the large asteroids.
        self.large_asteroid1.advance()
        self.large_asteroid2.advance()
        self.large_asteroid3.advance()
        self.large_asteroid4.advance()
        self.large_asteroid5.advance()

        # TODO: Check for collisions

    def check_keys(self):
        """
        This function checks for keys that are being held down.
        You will need to put your own method calls in here.
        """
        if arcade.key.LEFT in self.held_keys:
            pass

        if arcade.key.RIGHT in self.held_keys:
            pass

        if arcade.key.UP in self.held_keys:
            pass

        if arcade.key.DOWN in self.held_keys:
            pass

        # Machine gun mode...
        #if arcade.key.SPACE in self.held_keys:
        #    pass


    def on_key_press(self, key: int, modifiers: int):
        """
        Puts the current key in the set of keys that are being held.
        You will need to add things here to handle firing the bullet.
        """
        if self.ship.alive:
            self.held_keys.add(key)

            if key == arcade.key.SPACE:
                # TODO: Fire the bullet here!
                pass

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            self.held_keys.remove(key)
