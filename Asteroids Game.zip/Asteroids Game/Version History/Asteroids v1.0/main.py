"""
File: main.py
Author: Jaden Mounteer

This file runs the game, Asteroids.
"""
# Imports
import arcade
import asteroids_game

def main():
    """
    Main method
    """
    # Creates an instance of the game in a variable called Window
    window = asteroids_game.Game(asteroids_game.SCREEN_WIDTH, asteroids_game.SCREEN_HEIGHT)

    # Starts running the game
    arcade.run()

# Runs the game by calling the main function.
if __name__ == "__main__":
    main()