"""
File: velocity.py
Author: Jaden Mounteer

This file creates a class to represent the velocity
of an object.
"""

class Velocity():
    """
    Represents the velocity
    of an object.
    """
    def __init__(self):
        """
        Initiates the derivatives (dx and dy)
        of an object to floats.
        """
        self.dx = 0.0
        self.dy = 0.0
