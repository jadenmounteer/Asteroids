"""
File: ship.py
Author: Jaden Mounteer

This file creates a ship class, a child of the
flying object class.
"""
# Imports
import arcade
from flying_object import Flying_object
import asteroids_game


class Ship(Flying_object):
    """
    Represents a starship controlled
    by the player. It is a child class
    of the Flying_object base class.
    """
    def __init__(self):
        """ Initiates the ship's member variables."""
        # Calls the super function so that we can manipulate
        # some of the flying object's methods, while keeping others.
        super().__init__()

        # Sets the ship's starting position to be the middle of the screen.
        #self.center.x = asteroids_game.SCREEN_HEIGHT / 2
        #self.center.y = asteroids_game.SCREEN_WIDTH / 2
        self.center.x = 300
        self.center.y = 400

        # Sets the ship's velocity to be the ship's thrust amount.
        self.velocity.dx = asteroids_game.SHIP_THRUST_AMOUNT
        self.velocity.dy = asteroids_game.SHIP_THRUST_AMOUNT

        # Creates an attribute for the angle of the ship.
        self.angle = 90  # TODO: Set this to an integer. How? What integer?

    def draw(self):
        """
        Draws the ship to the screen.
        :return: None
        """
        # Sets the texture of the ship to be the image playerShip1_orange.png
        # found in the Image directory.
        img = "Images/playerShip1_orange.png"

        # loads the image into a texture class with the image as a parameter.
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 1  # For transparency, 1 means not transparent.

        x = self.center.x
        y = self.center.y
        angle = 90

        # TODO: Figure out how the alpha works. 1 doesn't seem to work.
        arcade.draw_texture_rectangle(x, y, width, height, texture, angle, angle)

    def move_up(self):
        """
        Changes the angle of the ship
        and moves up the y axis.
        """
        pass

    def move_down(self):
        """
        Changes the angle of the ship
        and moves down the y axis.
        """
        pass

    def move_right(self):
        """
        Changes the angle of the ship
        and moves up the x axis.
        """
        pass

    def move_left(self):
        """
        Changes the angle of the ship
        and moves down the x axis.
        """
        pass





