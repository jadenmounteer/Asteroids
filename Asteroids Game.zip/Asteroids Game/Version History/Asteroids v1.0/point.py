"""
File: point.py
Author: Jaden Mounteer

This file creates a class to represent a point coordinate
on the screen.
"""

class Point():
    """
    Represents a point coordinate.
    """
    def __init__(self):
        """
        Initiates the x and y coordinates at a float.
        """
        self.x = 0.0
        self.y = 0.0
