"""
File: ship.py
Author: Jaden Mounteer

This file creates a ship class, a child of the
flying object class.
"""
# Imports
import arcade
from flying_object import Flying_object
import asteroids_game
import math


class Ship(Flying_object):
    """
    Represents a starship controlled
    by the player. It is a child class
    of the Flying_object base class.
    """
    def __init__(self):
        """ Initiates the ship's member variables."""
        # Calls the super function so that we can manipulate
        # some of the flying object's methods, while keeping others.
        super().__init__()

        # Sets the ship's starting position to be the middle of the screen.
        self.center.x = asteroids_game.SCREEN_HEIGHT / 2
        self.center.y = asteroids_game.SCREEN_WIDTH / 2

        # Sets the ship's velocity
        self.velocity.dx = 0
        self.velocity.dy = 0

        # Creates an attribute for the starting angle of the ship.
        self._angle = 90

        # Creates an attribute for the starting angle of the ship in radians.
        self.angle_rad = 0

        # Inititates the radius of the ship to 30 for collision detection.
        self.radius = 40

    def draw(self):
        """
        Draws the ship to the screen.
        :return: None
        """
        # Sets the texture of the ship to be the image playerShip1_orange.png
        # found in the Image directory.
        # Loads the orange ship.
        #img = "Images/playerShip1_orange.png"
        img = "Images/The Enterprise.png"


        # loads the image into a texture class with the image as a parameter.
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255  # For transparency, 255 means not transparent.

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, (self._angle - 90), alpha)

    def thrust(self):
        """
        Increases the velocity of the ship in the direction
        it is pointed by 0.25 pixels/frame
        """
        # Convert angle in degrees to radians.
        self.angle_rad = math.radians(self._angle)

        # Increases the velocity of the ship based on the angle.
        self.velocity.dx += math.cos(self.angle_rad) * asteroids_game.SHIP_THRUST_AMOUNT
        self.velocity.dy += math.sin(self.angle_rad) * asteroids_game.SHIP_THRUST_AMOUNT

    def impact_detection(self, asteroids):
        """
        This method warns the starship that
        impact is imminent when an object
        is within a certain distance.
        Takes a list of asteroids as a parameter.
        """
        # Loops through the list of asteroids.
        for asteroid in asteroids:
            # gets the distance of the asteroid from the ship
            distance = self.get_distance(asteroid) / 1000
            # if the distance is less than 20
            if int(distance) <= 15:
                print("Impact imminent!")
                self.draw_impact_imminent()

            #print(distance)


    def get_distance(self, object_in_question):
        """
        Returns the distance of an object from the ship.
        """
        # Stores the npc's position and object's position in variables to be used in the distance equation.
        x1 = self.center.x
        y1 = self.center.y
        x2 = object_in_question.center.x
        y2 = object_in_question.center.y

        # Finds the horizontal and vertical distance between the points.
        vertical_distance = y2 - y1
        horizontal_distance = x2 - x1

        # Squares both values.
        square_root_of_vertical_distance = vertical_distance ** 2
        square_root_of_horizontal_distance = horizontal_distance ** 2

        # Adds the sum and stores them in a variable.
        distance_from_object = square_root_of_vertical_distance + square_root_of_horizontal_distance

        return distance_from_object

    def draw_impact_imminent(self):
        """
        Draws impact imminent to the screen
        """
        text = "IMPACT IMMINENT "
        start_x = asteroids_game.SCREEN_WIDTH / 2 - 100
        start_y = asteroids_game.SCREEN_HEIGHT - 50
        arcade.draw_text(text, start_x=start_x, start_y=start_y, font_size=25,
                         color=arcade.color.RED)

















