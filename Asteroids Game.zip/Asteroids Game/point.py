"""
File: point.py
Author: Jaden Mounteer

This file creates a class to represent a point coordinate
on the screen.
"""
import asteroids_game

class Point():
    """
    Represents a point coordinate.
    """
    def __init__(self):
        """
        Initiates the x and y coordinates at a float.
        """
        self._x = 0.0
        self._y = 0.0


    # Creates the getters and setters for the x and y attributes.
    def get_x(self):
        """
        :return self._x:
        """
        return self._x

    def set_x(self, x):
        """
        If the location of the object falls off the screen,
        puts it back on the opposite end.
        """
        # If it falls off the left hand side of the screen
        if self._x <= -50:
            # brings the object back to the right hand side.
            self._x = asteroids_game.SCREEN_WIDTH + 40

        # If it falls off the right hand side of the screen
        elif self._x - 50 > asteroids_game.SCREEN_WIDTH:
            # brings the object back to the left hand side of the screen
            self._x = -40

        # If its still on the screen
        else:
            # Business as usual.
            self._x = x


    def get_y(self):
        """
        :return self._y:
        """
        return self._y

    def set_y(self, y):
        """
        If the location of the object falls off the screen,
        puts it back on the opposite end.
        """
        # If it falls off the bottom of the screen
        if self._y <= -50:
            # brings the object to the top of the screen.
            self._y = asteroids_game.SCREEN_HEIGHT + 40
            #print("An asteroid fell off the bottom of the screen.")

        # If it falls off the top of the screen
        elif self._y - 50 > asteroids_game.SCREEN_HEIGHT:
            # brings the object to the bottom of the screen
            self._y = -40
            #print("An asteroid fell off the top of the screen.")

        # If its still on the screen
        else:
            # business as usual.
            self._y = y

    # Creates the properties for the x and y attributes.
    x = property(get_x, set_x)
    y = property(get_y, set_y)


