"""
File: velocity.py
Author: Jaden Mounteer

This file creates a class to represent the velocity
of an object.
"""

class Velocity():
    """
    Represents the velocity
    of an object.
    """
    def __init__(self):
        """
        Initiates the derivatives (dx and dy)
        of an object to floats.
        """
        self._dx = 0.0
        self._dy = 0.0


    def _get_dx(self):
        """
        Returns the dx attribute of the ship's velocity.
        """
        return self._dx

    def _set_dx(self, dx):
        """
        Sets the speed_dx element of of the ship so
        it can't go below or above 5.
        """
        if self._dx < -3:
            self._dx = -3
        elif self._dx > 3:
            self._dx = 3
        else:
            self._dx = dx

    def _get_dy(self):
        """
        Returns the dy attribute of the ship's velocity.
        """
        return self._dy

    def _set_dy(self, dy):
        """
        Sets the speed_dy element of of the ship so
        it can't go below or above 5.
        """
        if self._dy < -3:
            self._dy = -3
        elif self._dy > 3:
            self._dy = 3
        else:
            self._dy = dy

    # Creates the properties of the ship's velocity.
    dx = property(_get_dx, _set_dx)
    dy = property(_get_dy, _set_dy)
