"""
File: explosion.py
Author: Jaden Mounteer

This class represents an explosion after the object in
the game explodes.
"""
import arcade
from point import Point
from velocity import Velocity

class Explosion():
    """
    This class represents an explosion after the object in
    the game explodes. Takes the x and y coordinates as parameters
    in the init() method.
    """
    def __init__(self, x, y):
        self.center = Point()
        self.velocity = Velocity()

        self.center.x = x
        self.center.y = y

        self.angle = 0

        self.count = 0

    def draw(self):
        """
        Draws the explosion to the screen.
        """
        img = "Images/explosion.png"
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, self.angle, alpha)

class Small_Explosion(Explosion):
    """
    This class represents an explosion after the object in
    the game explodes. Takes the x and y coordinates as parameters
    in the init() method.
    """
    def __init__(self, x, y):
        super().__init__(x, y)

    def draw(self):
        """
        Draws the explosion to the screen.
        """
        img = "Images/explosion2.png"
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, self.angle, alpha)