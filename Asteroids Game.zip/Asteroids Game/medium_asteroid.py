"""
File: medium_asteroid.py
Author: Jaden Mounteer

This file creates a parent class to represent a medium asteroid
in the game.
"""

# Imports
import asteroid_base_class
import arcade
import random

class Medium_Asteroid(asteroid_base_class.Asteroid):
    """
    Represents a medium asteroid in the game.
    Child class of the asteroid class.
    """
    def __init__(self, x, y, dx, dy):
        # Calls the super function so that we can manipulate
        # some of the asteroid's methods, while keeping others.
        super().__init__()

        # Initiates the location of the asteroid.
        self.center.x = x
        self.center.y = y

        # Initiates the speed of the asteroid.
        self.velocity.dx = dx
        self.velocity.dy = dy

        # Initiates a radius attribute for collision detection.
        self.radius = 5

        # Creates an attribute for the type of asteroid.
        self.type = "medium"

        # Initiates the rotation of the asteroid.
        self.rotation = -2

        # Initiates the angle of the asteroid.
        self.angle = 90

    def draw(self):
        """
        Draws the asteroid to the screen.
        """
        img = "Images/meteorGrey_med1.png"
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, self.angle, alpha)

    def break_apart(self):
        """
        Causes the asteroid to break apart and split into
        small asteroids.
        """
        pass

    def hit(self):
        """
        Simulates the asteroid being hit.
        :return: a point for the player.
        """
        pass
