___Installation___


___TO Do List___
o Make the velocity of the ship a property that can't pass a certain amount.
For example, if you increase the thrust, it will only increase up to a certain point
o figure out how to keep track of the direction of a sprite.
o In order to find the direction, or to make the angle not change, use properties.