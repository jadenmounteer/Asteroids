"""
File: bullet.py
Author: Jaden Mounteer

This file creates a bullet class, a child of the
flying object class.
"""
# Imports
from flying_object import Flying_object
import asteroids_game
import math
import arcade


class Bullet(Flying_object):
    """
    Represents a bullet in the game, a child
    of the flying object class.
    """
    def __init__(self, ship_center_x, ship_center_y, angle_of_ship, ship_dx_speed, ship_dy_speed):
        # Calls the super function so that we can manipulate
        # some of the flying object's methods, while keeping others.
        super().__init__()

        # Sets the location of the bullet to be the location of the player's ship.
        self.center.x = ship_center_x
        self.center.y = ship_center_y

        # Sets the initial velocity of the bullet.
        self.speed_dx = ship_dx_speed
        self.speed_dy = ship_dy_speed

        # Sets the angle of the bullet to the angle of the ship.
        self.angle = angle_of_ship

        # Declares a variable for count
        self.count = 0

        # Angles the bullet horizontally.
        self.added_speed_x = math.cos(math.radians(angle_of_ship)) * asteroids_game.BULLET_SPEED
        # Angles the bullet vertically.
        self.added_speed_y = math.sin(math.radians(angle_of_ship)) * asteroids_game.BULLET_SPEED

        # Initiates the radius of the bullet to 30 for collision detection.
        self.radius = 30

    def draw(self):
        """
        Draws the bullet to the screen.
        """
        # Sets the texture of the bullet to be the image laserBlue01.png
        # found in the Image directory.
        img = "Images/laserBlue01.png"

        # loads the image into a texture class with the image as a parameter.
        texture = arcade.load_texture(img)

        width = texture.width
        height = texture.height
        alpha = 255  # For transparency, 1 means not transparent.

        x = self.center.x
        y = self.center.y

        arcade.draw_texture_rectangle(x, y, width, height, texture, self.angle, alpha)

    def advance(self):
        """
        Makes the bullet object move.
        Bullet survives for 60 frames and then dies.
        :return: None
        """
        if self.alive:
            self.center.x += self.speed_dx + self.added_speed_x
            self.center.y += self.speed_dy + self.added_speed_y
            # Causes the bullet to die after 60 frames.
            self.count += 1
        if self.count > 60:
            self.alive = False
            print("Bullet dies.")


